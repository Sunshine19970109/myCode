package test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestListener2 {
	
}
