package service.impl;

import service.PushService;

public class ClientPushServiceImpl implements PushService {

	public void push(Object info) {
		// TODO Auto-generated method stub

	}

}
